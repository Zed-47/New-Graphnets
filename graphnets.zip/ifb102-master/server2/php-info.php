<?php

// This exists for testing and making sure dependencies work
echo phpinfo();