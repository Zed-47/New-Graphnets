# Make sure containers aren't running
docker-compose down

# Build containers
docker-compose build

# Launch containers in foreground
docker-compose up